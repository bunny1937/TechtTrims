import React, { useEffect, useState } from "react";
import Layout from "../../components/Layout";
import OwnerSidebar from "../../components/OwnerSidebar";
import SalonCard from "../../components/SalonCard";

/**
 * pages/salons/dashboard.js
 *
 * A valid React page component (fixes the "default export is not a React Component" error).
 * Shows overview of bookings, notifications, and quick actions.
 */

export default function DashboardPage() {
  const [loading, setLoading] = useState(true);
  const [salon, setSalon] = useState(null);

  const [error, setError] = useState(null);
  const [bookings, setBookings] = useState([]);
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    let mounted = true;
    async function loadData() {
      setLoading(true);
      setError(null);

      // Fetch bookings
      try {
        const bRes = await fetch("/api/salons/bookings/today");
        if (!bRes.ok) throw new Error("Bookings fetch failed");
        const bJson = await bRes.json();
        if (mounted)
          setBookings(Array.isArray(bJson) ? bJson : bJson.bookings || []);
      } catch {
        try {
          const bRes2 = await fetch("/api/salons/bookings");
          if (bRes2.ok) {
            const bJson2 = await bRes2.json();
            if (mounted)
              setBookings(
                Array.isArray(bJson2) ? bJson2 : bJson2.bookings || []
              );
          } else {
            if (mounted) setError("Unable to fetch bookings from API.");
          }
        } catch {
          if (mounted) setError("Unable to fetch bookings from API.");
        }
      }
      try {
        const sRes = await fetch("/api/salons/profile");
        if (sRes.ok) {
          const sJson = await sRes.json();
          setSalon(sJson); // assume your API returns the salon object
        }
      } catch (e) {
        console.error("Failed to fetch salon profile", e);
      }
      // Fetch notifications (optional)
      try {
        const nRes = await fetch("/api/salons/notifications");
        if (nRes.ok) {
          const nJson = await nRes.json();
          if (mounted)
            setNotifications(
              Array.isArray(nJson) ? nJson : nJson.notifications || []
            );
        }
      } catch {
        // ignore missing endpoint
      }

      if (mounted) setLoading(false);
    }

    loadData();
    return () => {
      mounted = false;
    };
  }, []);

  function acceptNext() {
    if (bookings.length === 0) return alert("No bookings available");
    const next = bookings[0];
    setBookings((prev) => prev.slice(1));
    fetch(`/api/salons/bookings/${next.id}/accept`, { method: "POST" }).catch(
      () => setError("Failed to accept booking on server.")
    );
  }

  function markDone(id) {
    fetch(`/api/salons/bookings/${id}/complete`, { method: "POST" })
      .then((r) => {
        if (!r.ok) throw new Error("Failed");
        setBookings((prev) => prev.filter((b) => b.id !== id));
      })
      .catch(() => setError("Failed to mark booking done"));
  }

  function reschedule(id) {
    const newTime = prompt(
      "Enter new ISO datetime (e.g. 2025-09-22T18:30:00):"
    );
    if (!newTime) return;
    fetch(`/api/salons/bookings/${id}/reschedule`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ newTime }),
    })
      .then((r) => {
        if (!r.ok) throw new Error("reschedule failed");
        setBookings((prev) =>
          prev.map((b) => (b.id === id ? { ...b, time: newTime } : b))
        );
      })
      .catch(() => setError("Reschedule failed"));
  }

  const upcoming = bookings.slice(0, 3);
  const totalAppointments = bookings.length;

  return (
    <Layout>
      <div className="flex min-h-screen bg-gray-50">
        <aside className="w-64 border-r bg-white">
          <OwnerSidebar />
        </aside>

        <main className="flex-1 p-6">
          <div className="max-w-6xl mx-auto">
            <h1 className="text-2xl font-semibold mb-4">Salon Dashboard</h1>
            <div className="p-4 border-b bg-white shadow-sm">
              <h1 className="text-2xl font-bold">
                {salon ? salon.salonName : "My Salon"}
              </h1>
              <p className="text-gray-500">{salon?.ownerName}</p>
            </div>
            {/* Bookings Overview */}
            <section className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="col-span-2 bg-white p-4 rounded-lg shadow-sm">
                <h2 className="text-lg font-medium mb-2">
                  📊 Today&#39;s Bookings Overview
                </h2>
                <div>
                  <p className="text-sm text-gray-600">
                    Total appointments: <strong>{totalAppointments}</strong>
                  </p>
                  <div className="mt-3">
                    <h3 className="font-medium">Upcoming slots</h3>
                    {upcoming.length === 0 ? (
                      <p className="text-sm text-gray-500">
                        No upcoming bookings
                      </p>
                    ) : (
                      <ul className="space-y-2 mt-2">
                        {upcoming.map((b) => (
                          <li
                            key={b.id}
                            className="p-2 border rounded flex justify-between items-center"
                          >
                            <div>
                              <div className="text-sm font-medium">
                                {b.customerName || b.name || "Customer"}
                              </div>
                              <div className="text-xs text-gray-500">
                                {b.time || b.slot || "Time not set"}
                              </div>
                              <div className="text-xs text-gray-400">
                                {b.service ||
                                  b.services?.join(", ") ||
                                  "Service"}
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <button
                                onClick={() => markDone(b.id)}
                                className="px-3 py-1 bg-green-600 text-white rounded text-sm"
                              >
                                Mark Done
                              </button>
                              <button
                                onClick={() => reschedule(b.id)}
                                className="px-3 py-1 bg-yellow-500 text-white rounded text-sm"
                              >
                                Reschedule
                              </button>
                            </div>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>

                  <div className="mt-4 flex gap-2">
                    <button
                      onClick={acceptNext}
                      className="px-4 py-2 bg-blue-600 text-white rounded"
                    >
                      Accept Next
                    </button>
                    <button
                      onClick={() => alert("Open Add Walk-in modal")}
                      className="px-4 py-2 bg-gray-700 text-white rounded"
                    >
                      Add Walk-in
                    </button>
                    <button
                      onClick={() => alert("Open Block Time UI")}
                      className="px-4 py-2 bg-gray-500 text-white rounded"
                    >
                      Block/Unblock Slot
                    </button>
                  </div>
                </div>
                )
              </div>

              {/* Notifications */}
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h2 className="text-lg font-medium mb-2">🔔 Notifications</h2>
                {notifications.length === 0 ? (
                  <p className="text-sm text-gray-500">No notifications</p>
                ) : (
                  <ul className="space-y-2">
                    {notifications.map((n, i) => (
                      <li key={i} className="text-sm p-2 border rounded">
                        <div className="font-medium">
                          {n.title || "Notification"}
                        </div>
                        <div className="text-xs text-gray-500">
                          {n.message || n.body}
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </section>

            {/* Quick Management */}
            <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="col-span-2 bg-white p-4 rounded-lg shadow-sm">
                <h2 className="text-lg font-medium mb-2">
                  📅 Booking Management (Quick)
                </h2>
                <p className="text-sm text-gray-600 mb-2">
                  Calendar and queue management are in dedicated pages.
                </p>
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 border rounded">
                    <h3 className="font-medium">Queue</h3>
                    <p className="text-sm text-gray-500">
                      Walk-ins + online bookings (implement live sync).
                    </p>
                  </div>
                  <div className="p-3 border rounded">
                    <h3 className="font-medium">Reschedule & Swap</h3>
                    <p className="text-sm text-gray-500">
                      Drag & drop in calendar (to implement).
                    </p>
                  </div>
                </div>
              </div>

              {/* Shortcuts */}
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h2 className="text-lg font-medium mb-2">⚡ Quick Shortcuts</h2>
                <ul className="space-y-2 text-sm">
                  <li>
                    <button
                      className="underline"
                      onClick={() => alert("Open Staff Management")}
                    >
                      Manage Staff
                    </button>
                  </li>
                  <li>
                    <button
                      className="underline"
                      onClick={() => alert("Open Services & Pricing")}
                    >
                      Services & Pricing
                    </button>
                  </li>
                  <li>
                    <button
                      className="underline"
                      onClick={() => alert("Open Reports")}
                    >
                      Reports & Analytics
                    </button>
                  </li>
                </ul>
              </div>
            </section>

            {/* Salon Preview */}
            <section className="mt-6">
              <h2 className="text-lg font-medium mb-3">Salon Preview</h2>
              <SalonCard />
            </section>
          </div>
        </main>
      </div>
    </Layout>
  );
}
