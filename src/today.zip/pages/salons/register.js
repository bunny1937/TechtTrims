// pages/salons/register.js
import React from "react";
import SalonRegisterForm from "@/components/salons/SalonRegisterForm";

const SalonRegisterPage = () => {
  return (
    <div>
      <SalonRegisterForm />
    </div>
  );
};

export default SalonRegisterPage;
