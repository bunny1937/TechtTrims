// pages/salons/[id].js
import { useState, useEffect, useCallback } from "react";
import { useRouter } from "next/router";
import { motion } from "framer-motion";
import dynamic from "next/dynamic";
import styles from "../../styles/SalonDetail.module.css";
import Image from "next/image";

// Dynamic map import to avoid SSR issues
const MapContainer = dynamic(
  () => import("react-leaflet").then((mod) => mod.MapContainer),
  { ssr: false }
);
const TileLayer = dynamic(
  () => import("react-leaflet").then((mod) => mod.TileLayer),
  { ssr: false }
);
const Marker = dynamic(
  () => import("react-leaflet").then((mod) => mod.Marker),
  { ssr: false }
);

export default function SalonDetail({ initialSalon }) {
  const router = useRouter();
  const { id } = router.query;

  const [salon, setSalon] = useState(initialSalon || null);
  const [isLoading, setIsLoading] = useState(!initialSalon);
  const [selectedService, setSelectedService] = useState(null);
  const [selectedBarber, setSelectedBarber] = useState(null);
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedTime, setSelectedTime] = useState("");
  const [userOnboarding, setUserOnboarding] = useState(null);
  const [showBookingModal, setShowBookingModal] = useState(false);

  // Client re-fetch (optional, keeps data fresh if user navigates without reload)
  const loadSalonDetails = useCallback(async () => {
    if (!id) return;
    setIsLoading(true);
    try {
      const response = await fetch(`/api/salons/${id}`);
      const data = await response.json();
      if (response.ok) setSalon(data.salon);
    } catch (error) {
      console.error("Error loading salon:", error);
    } finally {
      setIsLoading(false);
    }
  }, [id]);

  useEffect(() => {
    if (id && !initialSalon) {
      loadSalonDetails();
    }

    // Get user onboarding data
    const onboardingData = localStorage.getItem("userOnboardingData");
    if (onboardingData) {
      setUserOnboarding(JSON.parse(onboardingData));
    }
  }, [id, loadSalonDetails, initialSalon]);

  // Time slot generator (same as before)
  const generateTimeSlots = () => {
    const slots = [];
    const today = new Date();
    const selectedDateObj = new Date(selectedDate);
    const startHour =
      selectedDateObj.toDateString() === today.toDateString()
        ? Math.max(9, today.getHours() + 1)
        : 9;
    const endHour = 20;

    for (let hour = startHour; hour < endHour; hour++) {
      for (let minute = 0; minute < 60; minute += 30) {
        const timeString = `${hour.toString().padStart(2, "0")}:${minute
          .toString()
          .padStart(2, "0")}`;
        slots.push({
          time: timeString,
          available: Math.random() > 0.3,
        });
      }
    }
    return slots;
  };

  const getFilteredServices = () => {
    if (!salon) return [];

    // Convert object → array
    const servicesArray = Object.entries(salon.services || {}).map(
      ([key, value]) => ({
        name: key,
        price: Number(value.price) || 0,
        enabled: value.enabled,
        duration: value.duration || 30, // fallback if not stored
        gender: value.gender || ["All"], // fallback if not stored
      })
    );

    if (!userOnboarding) return servicesArray;

    return servicesArray.filter(
      (service) =>
        service.gender.includes(userOnboarding.gender) ||
        service.gender.includes("All")
    );
  };

  if (isLoading) {
    return (
      <div className={styles.loadingContainer}>
        <div className={styles.spinner}></div>
        <p>Loading salon details...</p>
      </div>
    );
  }

  if (!salon) {
    return (
      <div className={styles.errorContainer}>
        <h2>Salon not found</h2>
        <button onClick={() => router.push("/")} className={styles.backButton}>
          ← Back to Home
        </button>
      </div>
    );
  }

  // Add missing handleBookAppointment function
  const handleBookAppointment = () => {
    setShowBookingModal(true);
  };

  return (
    <div className={styles.container}>
      {/* Header */}
      <header className={styles.header}>
        <button onClick={() => router.back()} className={styles.backButton}>
          ← Back
        </button>
        <h1 className={styles.salonName}>{salon.salonName}</h1>
        <div className={styles.headerActions}>
          <button className={styles.shareButton}>📤</button>
          <button className={styles.favoriteButton}>❤️</button>
        </div>
      </header>

      {/* Hero Section */}
      <motion.section
        className={styles.heroSection}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
      >
        <div className={styles.imageGallery}>
          {salon.salonImages && salon.salonImages.length > 0 ? (
            <Image
              src={salon.salonImages[0]}
              alt={salon.salonName}
              className={styles.mainImage}
            />
          ) : (
            <div className={styles.placeholderImage}>
              <span>📸</span>
              <p>No images available</p>
            </div>
          )}
        </div>

        <div className={styles.salonBasicInfo}>
          <div className={styles.ratingSection}>
            <div className={styles.mainRating}>
              ⭐ {salon.ratings.overall.toFixed(1)}
            </div>
            <div className={styles.reviewCount}>
              ({salon.ratings.totalReviews} reviews)
            </div>
          </div>

          <div className={styles.locationInfo}>
            <p>📍 {salon.location.address}</p>
            <p>📞 {salon.phone}</p>
          </div>

          <div className={styles.quickStats}>
            <div className={styles.stat}>
              <span className={styles.statNumber}>
                {salon.stats.totalBookings}
              </span>
              <span className={styles.statLabel}>Total Bookings</span>
            </div>
            <div className={styles.stat}>
              <span className={styles.statNumber}>
                {salon.stats.averageWaitTime}min
              </span>
              <span className={styles.statLabel}>Avg Wait Time</span>
            </div>
            <div className={styles.stat}>
              <span className={styles.statNumber}>
                {salon.stats.repeatCustomers}
              </span>
              <span className={styles.statLabel}>Repeat Customers</span>
            </div>
          </div>
        </div>
      </motion.section>

      {/* Services Section */}
      <motion.section
        className={styles.servicesSection}
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.2 }}
      >
        <h3 className={styles.sectionTitle}>Services & Pricing</h3>
        <div className={styles.servicesGrid}>
          {getFilteredServices().map((service, index) => (
            <motion.div
              key={index}
              className={`${styles.serviceCard} ${
                selectedService === service ? styles.selected : ""
              }`}
              onClick={() => setSelectedService(service)}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <h4 className={styles.serviceName}>{service.name}</h4>
              <p className={styles.servicePrice}>₹{service.price}</p>
              <p className={styles.serviceDuration}>{service.duration} min</p>
              <p className={styles.serviceGender}>
                {service.gender.join(", ")}
              </p>
            </motion.div>
          ))}
        </div>
      </motion.section>

      {/* Barber Selection Section */}
      {salon.barbers && salon.barbers.length > 0 && (
        <motion.section
          className={styles.barbersSection}
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          <h3 className={styles.sectionTitle}>Choose a Barber</h3>
          <div className={styles.barbersGrid}>
            {salon.barbers.map((barber, index) => (
              <motion.div
                key={barber.id || index}
                className={`${styles.barberCard} ${
                  selectedBarber === barber ? styles.selected : ""
                }`}
                onClick={() => setSelectedBarber(barber)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Image
                  src={barber.image || "/default-barber.png"}
                  alt={barber.name}
                  className={styles.barberImage}
                />
                <h4 className={styles.barberName}>{barber.name}</h4>
                <p className={styles.barberExperience}>
                  {barber.experience} yrs experience
                </p>
              </motion.div>
            ))}
          </div>
        </motion.section>
      )}

      {/* Date & Time Selection */}
      <motion.section
        className={styles.bookingSection}
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.6 }}
      >
        <h3 className={styles.sectionTitle}>Select Date & Time</h3>
        <div className={styles.dateTimePicker}>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className={styles.dateInput}
          />
          <div className={styles.timeSlots}>
            {selectedDate ? (
              generateTimeSlots().map((slot, idx) => (
                <button
                  key={idx}
                  className={`${styles.timeSlot} ${
                    selectedTime === slot.time ? styles.selected : ""
                  }`}
                  disabled={!slot.available}
                  onClick={() => setSelectedTime(slot.time)}
                >
                  {slot.time}
                </button>
              ))
            ) : (
              <p>Please select a date</p>
            )}
          </div>
        </div>
      </motion.section>

      {/* Map Section */}
      {salon.location.latitude && salon.location.longitude && (
        <motion.section
          className={styles.mapSection}
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
        >
          <h3 className={styles.sectionTitle}>Location</h3>
          <MapContainer
            center={[salon.location.latitude, salon.location.longitude]}
            zoom={15}
            style={{ height: "300px", width: "100%" }}
          >
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution="&copy; OpenStreetMap contributors"
            />
            <Marker
              position={[salon.location.latitude, salon.location.longitude]}
            />
          </MapContainer>
        </motion.section>
      )}

      {/* Book Appointment Button */}
      <div className={styles.bookButtonContainer}>
        <button
          className={styles.bookNowButton}
          onClick={handleBookAppointment}
          disabled={
            !selectedService ||
            !selectedBarber ||
            !selectedDate ||
            !selectedTime
          }
        >
          Book Appointment
        </button>
      </div>

      {/* Booking Modal */}
      {showBookingModal && (
        <div className={styles.modalOverlay}>
          <div className={styles.modalContent}>
            <h3>Confirm Your Booking</h3>
            <p>
              <strong>Service:</strong> {selectedService.name}
            </p>
            <p>
              <strong>Barber:</strong> {selectedBarber.name}
            </p>
            <p>
              <strong>Date:</strong> {selectedDate}
            </p>
            <p>
              <strong>Time:</strong> {selectedTime}
            </p>
            <div className={styles.modalActions}>
              <button
                className={styles.confirmButton}
                onClick={() => {
                  alert("Booking confirmed!");
                  setShowBookingModal(false);
                }}
              >
                Confirm
              </button>
              <button
                className={styles.cancelButton}
                onClick={() => setShowBookingModal(false)}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
export async function getServerSideProps(context) {
  const { id } = context.params;

  try {
    const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000";
    const response = await fetch(`${baseUrl}/api/salons/${id}`);
    const data = await response.json();

    if (!response.ok) {
      return { notFound: true };
    }

    return {
      props: {
        initialSalon: data.salon,
      },
    };
  } catch (error) {
    console.error("SSR fetch error:", error);
    return { notFound: true };
  }
}
