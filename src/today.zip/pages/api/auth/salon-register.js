// pages/api/auth/salons/register.js
// Proxy to canonical route /api/auth/salons/register
export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).end("Method Not Allowed");
  }
  try {
    const base = process.env.NEXT_PUBLIC_BASE_URL || "";
    const url = base + "/api/auth/salons/register";
    const r = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(req.body),
    });
    const data = await r.json();
    return res.status(r.status).json(data);
  } catch (e) {
    console.error("proxy error", e);
    return res.status(500).json({ message: "Proxy error", error: String(e) });
  }
}
