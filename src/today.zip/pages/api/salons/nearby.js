import { connectToDatabase } from "../../../lib/mongodb";

export default async function handler(req, res) {
  if (req.method !== "GET") {
    return res.status(405).json({ message: "Method Not Allowed" });
  }

  const { latitude, longitude, radius = "10" } = req.query;
  if (!latitude || !longitude) {
    return res.status(400).json({ message: "latitude and longitude required" });
  }

  const lat = parseFloat(latitude);
  const lng = parseFloat(longitude);
  const meters = parseFloat(radius) * 1000;

  try {
    const { db } = await connectToDatabase();

    // Ensure 2dsphere index exists
    await db.collection("salons").createIndex({ location: "2dsphere" });

    // Fetch salons near location
    const salons = await db
      .collection("salons")
      .find({
        location: {
          $near: {
            $geometry: { type: "Point", coordinates: [lng, lat] },
            $maxDistance: meters,
          },
        },
      })
      .limit(50)
      .toArray();

    // 🔥 Normalize documents
    const normalized = salons.map((s) => ({
      ...s,
      _id: s._id.toString(), // convert ObjectId → string
      topServices:
        s.topServices?.map((svc) => ({
          name: String(svc.name),
          price: Number(svc.price),
        })) || [],
      stats: s.stats
        ? {
            ...s.stats,
            totalBookings: Number(s.stats.totalBookings || 0),
          }
        : undefined,
    }));

    return res.status(200).json({ salons: normalized });
  } catch (err) {
    console.error(err);
    return res
      .status(500)
      .json({ message: "Server error", error: String(err) });
  }
}
