// pages/api/bookings/create.js
import { connectToDatabase } from "../../../lib/db/mongodb";
import { validateBooking } from "../../../lib/validators";
import { ObjectId } from "mongodb";

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  try {
    const validation = validateBooking(req.body);
    if (!validation.isValid) {
      return res.status(400).json({
        error: "Validation failed",
        details: validation.errors,
      });
    }

    const { db } = await connectToDatabase();

    const { salonId, barberName, service, scheduledTime, userDetails } =
      req.body;

    // Check if salon exists and is active
    const salon = await db.collection("salons").findOne({
      _id: new ObjectId(salonId),
      isActive: true,
    });

    if (!salon) {
      return res.status(404).json({ error: "Salon not found or inactive" });
    }

    // Check if the time slot is available
    const conflictingBooking = await db.collection("bookings").findOne({
      salonId,
      barberName,
      scheduledTime: new Date(scheduledTime),
      status: { $in: ["confirmed", "completed"] },
    });

    if (conflictingBooking) {
      return res.status(400).json({ error: "Time slot is already booked" });
    }

    // Create booking
    const bookingData = {
      salonId,
      barberName,
      service,
      scheduledTime: new Date(scheduledTime),
      status: "confirmed",
      userDetails,
      paymentStatus: "pending",
      feedback: {
        submitted: false,
        ratings: {},
        comment: "",
      },
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    const result = await db.collection("bookings").insertOne(bookingData);

    // Update salon stats
    await db.collection("salons").updateOne(
      { _id: new ObjectId(salonId) },
      {
        $inc: { "stats.totalBookings": 1 },
        $set: { updatedAt: new Date() },
      }
    );

    res.status(201).json({
      success: true,
      message: "Booking created successfully!",
      bookingId: result.insertedId,
      booking: {
        id: result.insertedId,
        salonName: salon.salonDetails.name,
        barberName,
        service,
        scheduledTime,
        status: "confirmed",
      },
    });
  } catch (error) {
    console.error("Booking creation error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
}
