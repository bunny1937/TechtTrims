import SalonRegisterForm from "@/components/salons/SalonRegisterForm";

export default function SalonRegisterPage() {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>Register Your Salon</h1>
      <SalonRegisterForm />
    </div>
  );
}
