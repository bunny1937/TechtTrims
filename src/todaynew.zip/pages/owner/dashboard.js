import { useState, useEffect } from "react";
import { useRouter } from "next/router";
import styles from "../../styles/Owner.module.css";
import OwnerSidebar from "../../components/OwnerSidebar";

export default function OwnerDashboard() {
  const router = useRouter();
  const [stats, setStats] = useState({
    todayBookings: 0,
    upcomingSlots: [],
    notifications: [],
  });
  const [quickActions, setQuickActions] = useState([]);

  useEffect(() => {
    // Check authentication
    const token = localStorage.getItem("ownerToken");
    if (!token) {
      router.push("/owner/login");
      return;
    }

    fetchDashboardData();
  }, [router]);

  const fetchDashboardData = async () => {
    // Fetch today's bookings and stats
    try {
      const response = await fetch("/api/owner/dashboard", {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("ownerToken")}`,
        },
      });
      const data = await response.json();
      setStats(data);
    } catch (error) {
      console.error("Error fetching dashboard:", error);
    }
  };

  const handleQuickAction = (action) => {
    switch (action) {
      case "accept":
        // Accept next customer
        break;
      case "reschedule":
        router.push("/owner/bookings");
        break;
      case "walkin":
        // Add walk-in customer
        showWalkInForm();
        break;
      case "block":
        // Block time slots
        router.push("/owner/schedule");
        break;
    }
  };

  const showWalkInForm = () => {
    // Simple prompt - in production use proper modal
    const name = prompt("Customer Name:");
    const service = prompt("Service:");
    if (name && service) {
      // Add walk-in booking
      console.log("Adding walk-in:", { name, service });
    }
  };

  return (
    <div className={styles.dashboard}>
      <OwnerSidebar />

      <div className={styles.content}>
        <div className={styles.header}>
          <h1>Dashboard</h1>
          <div className={styles.date}>{new Date().toLocaleDateString()}</div>
        </div>

        <div className={styles.statsGrid}>
          <div className={styles.statCard}>
            <h3>Today&#39;s Bookings</h3>
            <div className={styles.statNumber}>{stats.todayBookings}</div>
            <div className={styles.statSubtext}>
              Online: {stats.onlineBookings || 0} | Walk-in:{" "}
              {stats.walkInBookings || 0}
            </div>
          </div>

          <div className={styles.statCard}>
            <h3>Revenue Today</h3>
            <div className={styles.statNumber}>₹{stats.todayRevenue || 0}</div>
            <div className={styles.statSubtext}>
              Cash: ₹{stats.cashRevenue || 0} | UPI: ₹{stats.upiRevenue || 0}
            </div>
          </div>

          <div className={styles.statCard}>
            <h3>Active Staff</h3>
            <div className={styles.statNumber}>
              {stats.activeStaff || 0}/{stats.totalStaff || 0}
            </div>
            <div className={styles.statSubtext}>
              On break: {stats.onBreak || 0}
            </div>
          </div>

          <div className={styles.statCard}>
            <h3>Avg Wait Time</h3>
            <div className={styles.statNumber}>
              {stats.avgWaitTime || 15} min
            </div>
            <div className={styles.statSubtext}>Peak hours: 6-9 PM</div>
          </div>
        </div>

        <div className={styles.upcomingSection}>
          <h2>📅 Upcoming Appointments</h2>
          <div className={styles.appointmentList}>
            {stats.upcomingSlots?.map((slot, index) => (
              <div key={index} className={styles.appointmentCard}>
                <div className={styles.time}>{slot.time}</div>
                <div className={styles.customerInfo}>
                  <strong>{slot.customerName}</strong>
                  <span>{slot.service}</span>
                </div>
                <div className={styles.barber}>with {slot.barberName}</div>
                <button className={styles.actionBtn}>View</button>
              </div>
            ))}
          </div>
        </div>

        <div className={styles.quickActions}>
          <h2>⚡ Quick Actions</h2>
          <div className={styles.actionGrid}>
            <button
              onClick={() => handleQuickAction("accept")}
              className={styles.actionButton}
            >
              ✅ Accept Next
            </button>
            <button
              onClick={() => handleQuickAction("reschedule")}
              className={styles.actionButton}
            >
              🔄 Reschedule
            </button>
            <button
              onClick={() => handleQuickAction("walkin")}
              className={styles.actionButton}
            >
              🚶 Add Walk-in
            </button>
            <button
              onClick={() => handleQuickAction("block")}
              className={styles.actionButton}
            >
              🔒 Block Slots
            </button>
          </div>
        </div>

        <div className={styles.notifications}>
          <h2>🔔 Notifications</h2>
          <div className={styles.notificationList}>
            {stats.notifications?.map((notif, index) => (
              <div key={index} className={styles.notification}>
                <span className={styles.notifIcon}>{notif.icon}</span>
                <div className={styles.notifContent}>
                  <strong>{notif.title}</strong>
                  <p>{notif.message}</p>
                  <span className={styles.notifTime}>{notif.time}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
