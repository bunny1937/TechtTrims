import { useState, useEffect } from "react";
import styles from "../../styles/Owner.module.css";
import OwnerSidebar from "../../components/OwnerSidebar";

export default function ServicesManagement() {
  const [services, setServices] = useState([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingService, setEditingService] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    price: "",
    duration: "",
    gender: "all",
  });

  useEffect(() => {
    fetchServices();
  }, []);

  const fetchServices = async () => {
    try {
      const response = await fetch("/api/owner/services", {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("ownerToken")}`,
        },
      });
      const data = await response.json();
      setServices(data);
    } catch (error) {
      console.error("Error fetching services:", error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const url = editingService
        ? `/api/owner/services/${editingService.id}`
        : "/api/owner/services";

      const method = editingService ? "PUT" : "POST";

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("ownerToken")}`,
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        fetchServices();
        setShowAddForm(false);
        setEditingService(null);
        setFormData({
          name: "",
          description: "",
          price: "",
          duration: "",
          gender: "all",
        });
      }
    } catch (error) {
      console.error("Error saving service:", error);
    }
  };

  const handleEdit = (service) => {
    setEditingService(service);
    setFormData(service);
    setShowAddForm(true);
  };

  const handleDelete = async (serviceId) => {
    if (confirm("Are you sure you want to delete this service?")) {
      try {
        await fetch(`/api/owner/services/${serviceId}`, {
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${localStorage.getItem("ownerToken")}`,
          },
        });
        fetchServices();
      } catch (error) {
        console.error("Error deleting service:", error);
      }
    }
  };

  return (
    <div className={styles.dashboard}>
      <OwnerSidebar />

      <div className={styles.content}>
        <div className={styles.header}>
          <h1>Services & Pricing</h1>
          <button
            onClick={() => setShowAddForm(true)}
            className={styles.addButton}
          >
            + Add Service
          </button>
        </div>

        {showAddForm && (
          <div className={styles.formOverlay}>
            <div className={styles.formModal}>
              <h2>{editingService ? "Edit Service" : "Add New Service"}</h2>
              <form onSubmit={handleSubmit}>
                <div className={styles.formGroup}>
                  <label>Service Name</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    required
                  />
                </div>

                <div className={styles.formGroup}>
                  <label>Description</label>
                  <textarea
                    value={formData.description}
                    onChange={(e) =>
                      setFormData({ ...formData, description: e.target.value })
                    }
                    rows="3"
                  />
                </div>

                <div className={styles.formRow}>
                  <div className={styles.formGroup}>
                    <label>Price (₹)</label>
                    <input
                      type="number"
                      value={formData.price}
                      onChange={(e) =>
                        setFormData({ ...formData, price: e.target.value })
                      }
                      required
                    />
                  </div>

                  <div className={styles.formGroup}>
                    <label>Duration (mins)</label>
                    <input
                      type="number"
                      value={formData.duration}
                      onChange={(e) =>
                        setFormData({ ...formData, duration: e.target.value })
                      }
                      required
                    />
                  </div>

                  <div className={styles.formGroup}>
                    <label>For</label>
                    <select
                      value={formData.gender}
                      onChange={(e) =>
                        setFormData({ ...formData, gender: e.target.value })
                      }
                    >
                      <option value="all">Everyone</option>
                      <option value="male">Men</option>
                      <option value="female">Women</option>
                    </select>
                  </div>
                </div>

                <div className={styles.formActions}>
                  <button type="submit" className={styles.saveBtn}>
                    {editingService ? "Update" : "Add"} Service
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowAddForm(false);
                      setEditingService(null);
                    }}
                    className={styles.cancelBtn}
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        <div className={styles.servicesGrid}>
          {services.map((service) => (
            <div key={service.id} className={styles.serviceCard}>
              <div className={styles.serviceHeader}>
                <h3>{service.name}</h3>
                <span className={styles.genderBadge}>{service.gender}</span>
              </div>
              <p className={styles.serviceDesc}>{service.description}</p>
              <div className={styles.serviceDetails}>
                <span className={styles.price}>₹{service.price}</span>
                <span className={styles.duration}>{service.duration} mins</span>
              </div>
              <div className={styles.serviceActions}>
                <button
                  onClick={() => handleEdit(service)}
                  className={styles.editBtn}
                >
                  Edit
                </button>
                <button
                  onClick={() => handleDelete(service.id)}
                  className={styles.deleteBtn}
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className={styles.packagesSection}>
          <h2>🎁 Packages & Offers</h2>
          <button className={styles.addPackageBtn}>+ Create Package</button>

          <div className={styles.packageList}>
            <div className={styles.packageCard}>
              <h3>Weekend Special</h3>
              <p>Haircut + Beard Trim</p>
              <div className={styles.packagePrice}>
                <span className={styles.originalPrice}>₹350</span>
                <span className={styles.discountPrice}>₹250</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
