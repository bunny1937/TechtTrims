// pages/booking/confirmed.js
import { useRouter } from "next/router";
import { useEffect, useState } from "react";

export default function BookingConfirmed() {
  const router = useRouter();
  const { id } = router.query;
  const [booking, setBooking] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    (async () => {
      setLoading(true);
      const res = await fetch('/api/bookings/' + id);
      if (res.ok) {
        const data = await res.json();
        setBooking(data.booking);
      }
      setLoading(false);
    })();
  }, [id]);

  if (loading) return <div style={{padding:20}}>Loading...</div>;
  if (!booking) return <div style={{padding:20}}>Booking not found.</div>;

  return (
    <div style={{padding:20}}>
      <h2>Booking Confirmed</h2>
      <p><strong>Booking ID:</strong> {booking._id}</p>
      <p><strong>Salon:</strong> {booking.salonId}</p>
      <p><strong>Service:</strong> {booking.service}</p>
      <p><strong>Barber:</strong> {booking.barber}</p>
      <p><strong>Date:</strong> {booking.date} <strong>Time:</strong> {booking.time}</p>
      <p><strong>Customer:</strong> {booking.customerName} ({booking.customerPhone})</p>
    </div>
  );
}