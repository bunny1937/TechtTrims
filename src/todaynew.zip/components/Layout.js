import Link from "next/link";

export default function Layout({ children }) {
  return (
    <div className={"layout"}>
      <header className={"header"}>
        <div className={"logo"}>
          <h2>💈 SalonBook</h2>
        </div>
        <nav>
          <Link href="/">Home</Link>
          <Link href="/bookings">My Bookings</Link>
          <Link href="/profile">Profile</Link>
        </nav>
      </header>
      <main className={"main"}>{children}</main>
      <footer className={"footer"}>
        <p>&copy; 2024 SalonBook. All rights reserved.</p>
      </footer>
    </div>
  );
}
