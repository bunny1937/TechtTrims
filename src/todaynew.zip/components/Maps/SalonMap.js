// components/Maps/SalonMap.js - Map showing nearby salons
import React, { useEffect, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import { Star, MapPin, Phone } from "lucide-react";

const SalonMap = ({
  salons = [],
  userLocation,
  onSalonSelect,
  isDarkMode = false,
  height = "500px",
}) => {
  const [map, setMap] = useState(null);

  // Center map on user location or first salon
  const center = userLocation
    ? [userLocation.coordinates[1], userLocation.coordinates[0]]
    : salons.length > 0
    ? [
        salons[0].salonDetails.location.coordinates[1],
        salons[0].salonDetails.location.coordinates[0],
      ]
    : [19.076, 72.8777]; // Mumbai default

  useEffect(() => {
    if (map && salons.length > 0) {
      // Fit map to show all salons
      const bounds = salons.map((salon) => [
        salon.salonDetails.location.coordinates[1],
        salon.salonDetails.location.coordinates[0],
      ]);

      if (userLocation) {
        bounds.push([userLocation.coordinates[1], userLocation.coordinates[0]]);
      }

      if (bounds.length > 1) {
        map.fitBounds(bounds, { padding: [20, 20] });
      }
    }
  }, [map, salons, userLocation]);

  return (
    <div
      className={`rounded-xl overflow-hidden border-2 ${
        isDarkMode ? "border-gray-600" : "border-gray-300"
      }`}
      style={{ height }}
    >
      <MapContainer
        center={center}
        zoom={12}
        style={{ height: "100%", width: "100%" }}
        whenCreated={setMap}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        {/* User Location Marker */}
        {userLocation && (
          <Marker
            position={[
              userLocation.coordinates[1],
              userLocation.coordinates[0],
            ]}
          >
            <Popup>
              <div className="p-2">
                <p className="font-semibold text-blue-600">📍 Your Location</p>
              </div>
            </Popup>
          </Marker>
        )}

        {/* Salon Markers */}
        {salons.map((salon) => (
          <Marker
            key={salon._id}
            position={[
              salon.salonDetails.location.coordinates[1],
              salon.salonDetails.location.coordinates[0],
            ]}
            icon={salonIcon}
          >
            <Popup>
              <div className="p-3 min-w-[250px]">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-bold text-lg text-gray-900">
                    {salon.salonDetails.name}
                  </h3>
                  <div className="flex items-center ml-2">
                    <Star className="w-4 h-4 text-yellow-400 fill-current" />
                    <span className="text-sm font-semibold ml-1">
                      {salon.ratings.overall}
                    </span>
                  </div>
                </div>

                <div className="flex items-start mb-3">
                  <MapPin className="w-4 h-4 text-gray-500 mr-2 mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-gray-600">
                    {salon.salonDetails.address}
                  </p>
                </div>

                <div className="space-y-1 mb-3">
                  <p className="text-xs text-gray-500">Popular Services:</p>
                  {salon.topServices?.slice(0, 2).map((service, idx) => (
                    <div key={idx} className="flex justify-between text-sm">
                      <span>{service.name}</span>
                      <span className="font-semibold text-amber-600">
                        ₹{service.price}
                      </span>
                    </div>
                  ))}
                </div>

                {salon.distanceKm && (
                  <p className="text-xs text-blue-600 mb-2">
                    📍 {salon.distanceKm}km away
                  </p>
                )}

                <button
                  onClick={() => onSalonSelect && onSalonSelect(salon)}
                  className="w-full py-2 px-4 bg-gradient-to-r from-amber-500 to-yellow-600 text-white rounded-lg font-medium hover:from-amber-600 hover:to-yellow-700 transition-all duration-300"
                >
                  View Details
                </button>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
};

export default SalonMap;
